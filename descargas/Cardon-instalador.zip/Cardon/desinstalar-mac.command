#!/bin/bash
# Desinstalador de Cardón para Mac: quita la aplicación y el acceso del Escritorio.
# Los pacientes y medidas guardados solo se borran si el usuario lo confirma.
DIR="$HOME/Library/Application Support/Cardon"
echo ""
echo "  Desinstalando Cardón..."
rm -rf "$HOME/Applications/Cardón.app"
rm -f "$HOME/Desktop/Cardón"
rm -f "$DIR/Cardon.html"
if [ -d "$DIR/perfil" ]; then
  echo ""
  echo "  Los pacientes, medidas e imágenes guardados en Cardón en este Mac siguen guardados."
  echo "  Si los necesitas, haz antes una copia de seguridad desde Cardón (Inicio > Copia de seguridad)."
  read -r -p "  ¿Borrarlos también? Esto no se puede deshacer. Escribe BORRAR para confirmar: " R
  if [ "$R" = "BORRAR" ]; then rm -rf "$DIR"; echo "  Datos borrados."; else echo "  Los datos se conservaron en $DIR"; fi
else
  rmdir "$DIR" 2>/dev/null || true
fi
echo ""
echo "  Listo."
echo ""
