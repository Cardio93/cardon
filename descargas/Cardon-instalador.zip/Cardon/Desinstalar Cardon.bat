@echo off
chcp 65001 >nul
title Desinstalar Cardon
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0desinstalar.ps1"
pause
