﻿# Desinstalador de Cardón para Windows: quita los accesos directos y el programa.
# Los pacientes y medidas guardados solo se borran si el usuario lo confirma.
$dest = Join-Path $env:LOCALAPPDATA 'Cardon'
Write-Host ''
Write-Host '  Desinstalando Cardón...' -ForegroundColor Yellow
foreach ($folder in [Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs')) {
  if (-not $folder) { continue }
  $lnk = Join-Path $folder 'Cardón.lnk'
  if (Test-Path $lnk) { Remove-Item $lnk -Force; Write-Host "  Acceso directo quitado: $lnk" }
}
foreach ($f in 'Cardon.html', 'cardon.ico') { $p = Join-Path $dest $f; if (Test-Path $p) { Remove-Item $p -Force } }
$perfil = Join-Path $dest 'perfil'
if (Test-Path $perfil) {
  Write-Host ''
  Write-Host '  Los pacientes, medidas e imágenes guardados en Cardón en este computador siguen guardados.'
  Write-Host '  Si los necesitas, haz antes una copia de seguridad desde Cardón (Inicio > Copia de seguridad).'
  $r = Read-Host '  ¿Borrarlos también? Esto no se puede deshacer. Escribe BORRAR para confirmar'
  if ($r -ceq 'BORRAR') {
    try { Remove-Item $perfil -Recurse -Force; Write-Host '  Datos borrados.' }
    catch { Write-Host '  No se pudieron borrar todos los datos: cierra Cardón y vuelve a intentarlo.' -ForegroundColor Red }
  } else { Write-Host "  Los datos se conservaron en $perfil" }
}
if ((Test-Path $dest) -and -not (Get-ChildItem $dest -Force)) { Remove-Item $dest -Force }
Write-Host ''
Write-Host '  Listo.' -ForegroundColor Green
Write-Host ''
