#!/bin/bash
# Instalador de Cardón para Mac: copia Cardón a ~/Library/Application Support/Cardon y crea la
# aplicación «Cardón» (en Aplicaciones del usuario y en el Escritorio), que lo abre como programa,
# ocupando toda la pantalla y con su propio icono. Usa Google Chrome o Microsoft Edge.
set -e
SRC="$(cd "$(dirname "$0")" && pwd)"
DIR="$HOME/Library/Application Support/Cardon"
APPS="$HOME/Applications"
APP="$APPS/Cardón.app"
echo ""
echo "  Instalando Cardón..."
for f in Cardon.html cardon.icns; do
  if [ ! -f "$SRC/$f" ]; then echo "  Falta $f junto al instalador. Descomprime todo el .zip antes de instalar."; exit 1; fi
done
B=""
for c in "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" \
         "$HOME/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" \
         "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge" \
         "$HOME/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge" \
         "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser" \
         "/Applications/Chromium.app/Contents/MacOS/Chromium"; do
  if [ -x "$c" ]; then B="$c"; break; fi
done
if [ -z "$B" ]; then
  echo "  No se encontró Google Chrome ni Microsoft Edge. Instala uno de los dos y vuelve a ejecutar el instalador."
  echo "  (Safari no sirve: no permite abrir Cardón como programa.)"
  exit 1
fi
mkdir -p "$DIR" "$APPS"
cp "$SRC/Cardon.html" "$DIR/"
rm -rf "$APP"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
cp "$SRC/cardon.icns" "$APP/Contents/Resources/cardon.icns"
cat > "$APP/Contents/Info.plist" <<EOT
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleName</key><string>Cardón</string>
  <key>CFBundleDisplayName</key><string>Cardón</string>
  <key>CFBundleIdentifier</key><string>io.github.cardio93.cardon</string>
  <key>CFBundleExecutable</key><string>cardon</string>
  <key>CFBundleIconFile</key><string>cardon</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleShortVersionString</key><string>1.1</string>
  <key>LSMinimumSystemVersion</key><string>10.13</string>
  <key>NSHighResolutionCapable</key><true/>
</dict>
</plist>
EOT
# Lanzador: abre Cardón en su propia ventana, del tamaño de la pantalla (sin la barra de menú ni el Dock)
cat > "$APP/Contents/MacOS/cardon" <<'EOT'
#!/bin/bash
DIR="$HOME/Library/Application Support/Cardon"
B="__BROWSER__"
URL="file://$(printf '%s' "$DIR/Cardon.html" | sed 's/ /%20/g')"
GEO=$(osascript -l JavaScript -e 'ObjC.import("AppKit"); var s = $.NSScreen.mainScreen, f = s.frame, v = s.visibleFrame; [Math.round(v.origin.x), Math.round(f.size.height - v.origin.y - v.size.height), Math.round(v.size.width), Math.round(v.size.height)].join(",")' 2>/dev/null)
EXTRA=()
if [[ "$GEO" =~ ^([0-9]+),([0-9]+),([0-9]+),([0-9]+)$ ]]; then
  EXTRA=(--window-position="${BASH_REMATCH[1]},${BASH_REMATCH[2]}" --window-size="${BASH_REMATCH[3]},${BASH_REMATCH[4]}")
fi
exec "$B" --app="$URL" --user-data-dir="$DIR/perfil" --no-first-run --no-default-browser-check --start-maximized "${EXTRA[@]}"
EOT
ESC=$(printf '%s' "$B" | sed 's/[&|]/\\&/g')
sed -i '' "s|__BROWSER__|$ESC|" "$APP/Contents/MacOS/cardon" 2>/dev/null || sed -i "s|__BROWSER__|$ESC|" "$APP/Contents/MacOS/cardon"
chmod +x "$APP/Contents/MacOS/cardon"
xattr -dr com.apple.quarantine "$APP" 2>/dev/null || true
touch "$APP"
ln -sfn "$APP" "$HOME/Desktop/Cardón"
echo ""
echo "  Listo. Cardón quedó instalado."
echo "  Programa:   $APP"
echo "  Navegador:  $B"
echo ""
echo "  Ábrelo con el icono «Cardón» del Escritorio o desde Launchpad / Spotlight."
echo "  Para fijarlo en el Dock: ábrelo y, con clic derecho en su icono del Dock, elige Opciones > Mantener en el Dock."
echo "  Para actualizarlo, ejecuta de nuevo este instalador con el Cardon.html nuevo: los pacientes no se borran."
echo ""
read -r -p "  ¿Abrir Cardón ahora? (s/n) " R
case "$R" in [sS]*) open "$APP" ;; esac
