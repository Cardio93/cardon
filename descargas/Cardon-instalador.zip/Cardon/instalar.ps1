﻿# Instalador de Cardón para Windows (sin permisos de administrador).
# Copia Cardón a %LOCALAPPDATA%\Cardon y crea accesos directos en el Escritorio y en el menú Inicio
# que lo abren como aplicación, maximizado y con su propio icono.
$ErrorActionPreference = 'Stop'
$src  = Split-Path -Parent $MyInvocation.MyCommand.Path
$dest = Join-Path $env:LOCALAPPDATA 'Cardon'

function Find-Browser {
  $cands = @(
    (Join-Path ${env:ProgramFiles(x86)} 'Microsoft\Edge\Application\msedge.exe'),
    (Join-Path $env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe'),
    (Join-Path $env:LOCALAPPDATA 'Microsoft\Edge\Application\msedge.exe'),
    (Join-Path $env:ProgramFiles 'Google\Chrome\Application\chrome.exe'),
    (Join-Path ${env:ProgramFiles(x86)} 'Google\Chrome\Application\chrome.exe'),
    (Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe')
  )
  foreach ($c in $cands) { if ($c -and (Test-Path $c)) { return $c } }
  foreach ($exe in 'msedge.exe', 'chrome.exe') {
    foreach ($root in 'HKLM:', 'HKCU:') {
      $k = "$root\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\$exe"
      if (Test-Path $k) { $p = (Get-ItemProperty $k).'(default)'; if ($p -and (Test-Path $p)) { return $p } }
    }
  }
  return $null
}

try {
  Write-Host ''
  Write-Host '  Instalando Cardón...' -ForegroundColor Yellow
  foreach ($f in 'Cardon.html', 'cardon.ico') {
    if (-not (Test-Path (Join-Path $src $f))) { throw "Falta el archivo $f junto al instalador. Descomprime todo el .zip antes de instalar." }
  }
  $browser = Find-Browser
  if (-not $browser) { throw 'No se encontró Microsoft Edge ni Google Chrome. Instala uno de los dos y vuelve a ejecutar el instalador.' }

  New-Item -ItemType Directory -Force -Path $dest | Out-Null
  Copy-Item (Join-Path $src 'Cardon.html') $dest -Force
  Copy-Item (Join-Path $src 'cardon.ico') $dest -Force

  $html   = Join-Path $dest 'Cardon.html'
  $url    = ([System.Uri]$html).AbsoluteUri
  $perfil = Join-Path $dest 'perfil'
  # Perfil propio: Cardón abre siempre en su ventana, maximizado, y sus datos quedan separados del navegador.
  $arguments = "--app=`"$url`" --start-maximized --user-data-dir=`"$perfil`" --no-first-run --no-default-browser-check"

  $ws = New-Object -ComObject WScript.Shell
  $made = @()
  foreach ($folder in [Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs')) {
    if (-not $folder) { continue }
    $lnk = Join-Path $folder 'Cardón.lnk'
    $s = $ws.CreateShortcut($lnk)
    $s.TargetPath = $browser
    $s.Arguments = $arguments
    $s.WorkingDirectory = $dest
    $s.IconLocation = (Join-Path $dest 'cardon.ico') + ',0'
    $s.WindowStyle = 3
    $s.Description = 'Cardón: visor de imágenes cardiovasculares (uso educativo)'
    $s.Save()
    $made += $lnk
  }

  Write-Host ''
  Write-Host '  Listo. Cardón quedó instalado.' -ForegroundColor Green
  Write-Host "  Programa:  $dest"
  Write-Host "  Navegador: $browser"
  foreach ($m in $made) { Write-Host "  Acceso directo: $m" }
  Write-Host ''
  Write-Host '  Ábrelo con el icono «Cardón» del Escritorio o del menú Inicio.'
  Write-Host '  Para actualizarlo, ejecuta de nuevo este instalador con el Cardon.html nuevo: los pacientes no se borran.'
  Write-Host ''
  $r = Read-Host '  ¿Abrir Cardón ahora? (s/n)'
  if ($r -match '^[sS]') { Start-Process -FilePath $browser -ArgumentList $arguments -WindowStyle Maximized }
}
catch {
  Write-Host ''
  Write-Host ('  No se pudo instalar: ' + $_.Exception.Message) -ForegroundColor Red
  Write-Host ''
  exit 1
}
