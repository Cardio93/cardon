@echo off
chcp 65001 >nul
title Instalar Cardon
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar.ps1"
pause
