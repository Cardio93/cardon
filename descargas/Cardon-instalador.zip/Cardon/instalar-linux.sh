#!/bin/sh
# Instalador de Cardón para Linux (Ubuntu y similares): copia Cardón a ~/Cardon y crea el acceso
# en el menú de aplicaciones y en el Escritorio, que lo abre como aplicación, maximizado y con su icono.
set -e
SRC=$(cd "$(dirname "$0")" && pwd)
D="$HOME/Cardon"
for f in Cardon.html cardon.png; do
  [ -f "$SRC/$f" ] || { echo "Falta $f junto al instalador. Descomprime todo el .zip antes de instalar."; exit 1; }
done
B=""
for c in google-chrome google-chrome-stable chromium chromium-browser microsoft-edge microsoft-edge-stable brave-browser; do
  if command -v "$c" >/dev/null 2>&1; then B=$(command -v "$c"); break; fi
done
[ -n "$B" ] || { echo "No se encontró Chrome, Chromium ni Edge. Instala uno y vuelve a ejecutar el instalador."; exit 1; }
mkdir -p "$D"
cp "$SRC/Cardon.html" "$SRC/cardon.png" "$D/"
URL="file://$(printf '%s' "$D/Cardon.html" | sed 's/ /%%20/g')"
APPS="$HOME/.local/share/applications"; mkdir -p "$APPS"
DESK="$APPS/cardon.desktop"
cat > "$DESK" <<EOT
[Desktop Entry]
Type=Application
Name=Cardón
Comment=Visor de imágenes cardiovasculares (uso educativo)
Exec="$B" --app="$URL" --start-maximized --user-data-dir="$D/perfil" --no-first-run --no-default-browser-check
Icon=$D/cardon.png
Terminal=false
Categories=Graphics;MedicalSoftware;Science;
StartupWMClass=Cardon
EOT
chmod +x "$DESK"
ESC=$(xdg-user-dir DESKTOP 2>/dev/null || echo "$HOME/Desktop")
if [ -d "$ESC" ]; then
  cp "$DESK" "$ESC/cardon.desktop"; chmod +x "$ESC/cardon.desktop"
  gio set "$ESC/cardon.desktop" metadata::trusted true 2>/dev/null || true
fi
update-desktop-database "$APPS" 2>/dev/null || true
echo "Listo. Cardón quedó instalado en $D (navegador: $B)."
echo "Ábrelo desde el menú de aplicaciones o el icono del Escritorio."
